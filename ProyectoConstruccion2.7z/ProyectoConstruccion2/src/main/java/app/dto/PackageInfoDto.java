package app.dto;

public class PackageInfoDto {

}
