package app.models;

public class PackageInfo {

}
