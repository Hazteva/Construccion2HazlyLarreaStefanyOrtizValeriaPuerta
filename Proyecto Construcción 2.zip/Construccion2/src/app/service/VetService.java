package app.service;

import app.dto.PersonDto;
import app.dto.UserNameDto;

public class VetService implements AdministratorService, VeterinarianService{

	@Override
	public void createUser(UserNameDto userNameDto) throws Exception {
		// TODO Auto-generated method stub	
	}

	@Override
	public void createOwner(PersonDto personDto) throws Exception {
		// TODO Auto-generated method stub
		
	}
}


