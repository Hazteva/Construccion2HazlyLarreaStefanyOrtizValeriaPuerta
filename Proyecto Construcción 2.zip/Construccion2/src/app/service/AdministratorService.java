package app.service;

import app.dto.UserNameDto;

public interface AdministratorService {
	public void createUser (UserNameDto userNameDto) throws Exception;

	
}
